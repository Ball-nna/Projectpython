import pgzrun
import time
import random

def draw():
     if Game_over:
          screen.fill('red')
          screen.draw.text('Time out!!!,Your Points  is :'+str(points),(650,250),fontsize = 35)
          sounds.clear.play(-1)
          
     else:
          #screen.fill((60, 250, 250  ))
          screen.blit('map3',(0,0))
          screen.draw.filled_rect(floor,groundcolor)
          for i in platform:
               screen.draw.filled_rect(i,groundcolor)
          ninja.draw()
          coin.draw()
          sounds.ninja_music.play()
          screen.draw.text("Shuriken :"+str(points),(20,30),fontsize = 30)
          screen.draw.text("Time :"+str(time),(1350,20),fontsize=30)
    
def update():
     ninja_move()
     
def ninja_move():
     global ninja_x_velocity,ninja_y_velocity,jumping,gravity,jumped,points,c_xy,time
     #การเคลื่อนที่
     if ninja_x_velocity == 0 and not jumped:
          ninja.image = "crown"
     #gravity แรงโน้มถ่วงให้ตัวละครตก
     if collidecheck():
          gravity = 1
          ninja.y -= 1
          #allowx = True
          
     else:
          ninja.y += gravity
          if gravity <= 20:
               gravity += 0.5
     
               
     #ขยับตัวละครไปซ้าย-ขวา          
     if (keyboard.left):
          if (ninja.x > 40) and (ninja_x_velocity > -10):
               ninja_x_velocity -= 8
               ninja.image = "crownleft"
               sounds.jump.play()
               if(keyboard.left) and  jumped:
                    ninja.image = "crownjumpleft"
                    sounds.jump.play() 
     if(keyboard.right):
          if (ninja.x < 1650) and (ninja_x_velocity <10):
               ninja_x_velocity += 8
               ninja.image = "crownright"
               sounds.jump.play()
               if(keyboard.right) and jumped:
                    ninja.image ="crownjumpright"
                    sounds.jump.play()
     ninja.x +=  ninja_x_velocity
     
     #ความเร็วของตัวละคร สามารถปรับได้
     if ninja_x_velocity > 0:
          ninja_x_velocity -= 8
     if ninja_x_velocity < 0:
          ninja_x_velocity += 8
          
     #ตั้งค่าไม่ให้ตัวละครออกนอกกรอบ
     if ninja.x <30 or ninja.x >1650:
          ninja_x_velocity = 0
          
    #jump ทำให้ตัวละครกระโดดได้
     if (keyboard.up ) and collidecheck() and not jumped:
          jumping = True
          jumped = True
          clock.schedule_unique(jumpedrecently,0.2)
          ninja.image = "crownjump"
          sounds.jump.play(1)
          ninja_y_velocity = 95
     if  jumping and ninja_y_velocity >25:
          ninja_y_velocity = ninja_y_velocity - ((100-ninja_y_velocity)/2)
          #print(ninja_y_velocity)
          ninja.y -= ninja_y_velocity/3 #กระโดดสูง
     else:
          ninja_y_velocity = 0
          jumping = False
     #คะแนนตอนเก็บเหรียญ
     if ninja.colliderect(coin):
          points += 1
          time += 1
          sounds.gem.play()
          old_c_xy = c_xy
          c_xy = random.randint(0,9)
          while old_c_xy ==  c_xy:
               c_xy = random.randint(0,9)
          coin.x = coin_x[c_xy]
          coin.y = coin_y[c_xy]

def time_count():
     global time
     time += 1
def time_out():
     global Game_over
     Game_over = True


def jumpedrecently():
     global jumped
     jumped = False

           
def collidecheck():
      collide = False
      for i in platform:
           if ninja.colliderect(i):
                collide = True
      return collide 
      
    
#blueforward = True
TITLE = 'NINJACROWNGETSHURIKEN'
WIDTH = 1500
HEIGHT = 700
ninja = Actor('crown',(755,550))
points = 0
time = 0
#Max_time = 5
Game_over = False
clock.schedule(time_out,20.0)
clock.schedule_interval(time_count,1.0)
ninja_x_velocity = 0
ninja_y_velocity = 0
gravity = 3

jumping = False
jumped = False
groundcolor = (0,0,0)

floor = Rect((0,680),(1700,20))
plat1 = Rect((750,650),(140,20) )
plat2 = Rect((550,550),(120,12) )
plat3 = Rect((950,550),(120,12) )
plat4 = Rect((350,450),(120,12) )
plat5 = Rect((1200,450),(120,12) )
plat6 = Rect((170,350),(120,12) )
plat7 = Rect((1350,350),(120,12) )
plat8 = Rect((750,230),(150,12))
plat9 = Rect((400,150),(150,12))
plat10 = Rect((1100,150),(150,12))



#coin
coin_x = [800,600,1000,400,1250,220,1350,800,450,1150]
coin_y = [620,520,520,420,420,320,320,220,120,120]
c_xy = random.randint(0,9)
coin = Actor('coin',(coin_x[c_xy],coin_y[c_xy]))


#music.play('jojo')

platform = [floor,plat1,plat2,plat3,plat4,plat5,plat6,plat7,plat8,plat9,plat10]
pgzrun.go()
